package skeleton;

/**
 *
 */

public interface SkeletonScreen {

    void show();

    void hide();
}
